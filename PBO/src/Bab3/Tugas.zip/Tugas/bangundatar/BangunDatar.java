package Bab3.Tugas.bangundatar;

public class BangunDatar {
    private double luas, keliling;

    public double Luas(double luas) {
        this.luas = luas;
        return this.luas;
    }

    public double Keliling(double keliling) {
        this.keliling = keliling;
        return this.keliling;
    }

    public double Luas() {
        return luas;
    }

    public double Keliling() {
        return keliling;
    }
}
