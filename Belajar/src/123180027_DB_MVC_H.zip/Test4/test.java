package Test4;

public class test {
//    static Object[][] data = new Object[50][8];
//    static Model model = new Model();
//    public static void main(String[] args) {
//        data = model.Find(2299999);
//        System.out.println(data[0][0]);
//    }
}
